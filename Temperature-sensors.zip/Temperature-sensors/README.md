# Павленко Богдан
## Варіант 2
## Temperature-sensors
