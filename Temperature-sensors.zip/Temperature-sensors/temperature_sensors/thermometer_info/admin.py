from django.contrib import admin

# Register your models here.
from thermometer_info.models import Thermometer

admin.site.register(Thermometer)
